from django.contrib import admin
from .models import RegistrosSimulacionesCreditos

admin.site.register(RegistrosSimulacionesCreditos)
